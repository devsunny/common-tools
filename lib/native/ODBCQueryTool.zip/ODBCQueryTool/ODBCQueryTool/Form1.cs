﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Odbc;

namespace ODBCQueryTool
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string dns = "DSN=" + txtDSN.Text;
            string sql = this.rtbSql.Text;           
            if (dns != null && dns.Length > 0 && sql != null && sql.Length > 0)
            {
                System.Data.Odbc.OdbcConnection conn = new System.Data.Odbc.OdbcConnection(dns);               
                try
                {
                    System.Data.Odbc.OdbcDataAdapter dataAdapter = new System.Data.Odbc.OdbcDataAdapter(sql, conn); //c.con is the connection string
                    OdbcCommandBuilder builder =  new OdbcCommandBuilder(dataAdapter);
                    conn.Open();
                    DataSet ds = new DataSet();
                    dataAdapter.Fill(ds);
                    dataGridView1.ReadOnly = true;
                    dataGridView1.DataSource = ds.Tables[0];
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Failed to connect to data source:" + ex.Message);
                    this.rtbSql.Text = this.rtbSql.Text + "\n" + ex.Message;
                }
                finally
                {
                    conn.Close();
                }
            }
            
        }

        private void txtDSN_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
