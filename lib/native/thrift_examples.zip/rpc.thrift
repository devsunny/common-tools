namespace java com.asksunny.rpc
namespace perl asksunny.rpc
namespace cpp asksunny.rpc


struct RpcObject{
  1: required i32 type ,
  2: required string value,
}

struct Parameter {
  1: required RpcObject rpcObject
  3: optional string name,
  4: optional i32 index,
}

typedef list<Parameter> ParameterList

struct command {
	1: required string name,
	2: optional ParameterList parameters,
}

typedef list<RpcObject> RpcObjectList

typedef list<RpcObjectList> RpcObjectsList

enum ResponseType {
    VOID = 0,
    SINGLE_OBJECT = 1,
    LIST = 2,
    LIST_OF_LIST = 3,
}

struct RpcResponse {
	1: required i32 responseType,
	2: optional RpcObject singleObject,
	3: optional RpcObjectList listOfObject,
	4: optional RpcObjectsList listOfObjects,
}

exception InvocationException {
  1: required i32 errorCode,
  2: optional string message
}

service RpcGateway {
	void ping(),
	RpcResponse invokeRpc(1: ParameterList parameters) throws (1:InvocationException error),
}






